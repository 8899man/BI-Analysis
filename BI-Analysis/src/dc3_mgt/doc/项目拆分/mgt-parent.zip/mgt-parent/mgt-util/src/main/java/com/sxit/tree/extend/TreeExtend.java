package com.sxit.tree.extend;

import com.sxit.tree.PNode;

public interface TreeExtend {
	
	public void invoke(PNode pnode) throws Exception;
	
}
