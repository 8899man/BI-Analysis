package com.sxit.mgt.system.dto;


/**
 * @公司:深讯信科
 * @功能:用户管理 Model
 * @作者:张如兵
 * @日期:2015-02-26 22:17:32
 * @版本:1.0
 * @修改:
 */

public class UserVo {
	private String userName;
	
	private String name;
	
	public UserVo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

}
