package com.sxit.common.excel;

public enum DataEnum {

	String, Date, Timestamp, Boolean, Int, Long, Float, Double, BigDecimal, Map;

}
