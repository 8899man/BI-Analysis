package com.sxit.model.common;

public class StringMap {
	private String keystr;
	private String valuestr;

	public StringMap() {
		super();
		// Auto-generated constructor stub
	}

	public StringMap(String keystr, String valuestr) {
		super();
		this.keystr = keystr;
		this.valuestr = valuestr;
	}

	public String getKeystr() {
		return keystr;
	}

	public void setKeystr(String keystr) {
		this.keystr = keystr;
	}

	public String getValuestr() {
		return valuestr;
	}

	public void setValuestr(String valuestr) {
		this.valuestr = valuestr;
	}

}
