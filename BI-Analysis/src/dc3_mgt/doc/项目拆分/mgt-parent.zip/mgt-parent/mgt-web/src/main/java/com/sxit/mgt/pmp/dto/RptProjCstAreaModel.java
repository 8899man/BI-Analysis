package com.sxit.mgt.pmp.dto;

public class RptProjCstAreaModel{
	

		private Long cst_area_id;//   	private String proj_id;//   	private String area_id;//   	private Integer cst_num;//   	private java.sql.Timestamp create_time;//   	public Long getCst_area_id() {	    return this.cst_area_id;	}	public void setCst_area_id(Long cst_area_id) {	    this.cst_area_id=cst_area_id;	}	public String getProj_id() {	    return this.proj_id;	}	public void setProj_id(String proj_id) {	    this.proj_id=proj_id;	}	public String getArea_id() {	    return this.area_id;	}	public void setArea_id(String area_id) {	    this.area_id=area_id;	}	public Integer getCst_num() {	    return this.cst_num;	}	public void setCst_num(Integer cst_num) {	    this.cst_num=cst_num;	}	public java.sql.Timestamp getCreate_time() {	    return this.create_time;	}	public void setCreate_time(java.sql.Timestamp create_time) {	    this.create_time=create_time;	}
	
}
