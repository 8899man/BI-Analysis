	return $.fn.jstree;
}));