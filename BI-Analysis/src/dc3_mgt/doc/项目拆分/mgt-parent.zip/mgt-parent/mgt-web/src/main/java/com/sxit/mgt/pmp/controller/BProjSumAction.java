package com.sxit.mgt.pmp.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;


import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.sxit.common.action.BaseAction;
import com.sxit.common.annatation.AuthPassport;
import com.sxit.common.dto.ResultMessage;
import com.sxit.common.dto.SearchVo;
import com.sxit.common.pagehelper.Page;
import com.sxit.common.pagehelper.PageVo;
import com.sxit.model.pmp.BProjSum;

import com.sxit.mgt.pmp.dto.BProjSumModel;
import com.sxit.mgt.pmp.service.BProjSumService;

/**
 * @公司:深讯信科
 * @功能:BProjSum Action
 * @作者:Edson.di   
 * @日期:2015-09-23 09:43:07  
 * @版本:1.0
 * @修改:
 */

@Controller
@RequestMapping("/pmp")
public class BProjSumAction extends BaseAction{
	
	private final static Logger log= Logger.getLogger(BProjSumAction.class);
	
	@Autowired
	private BProjSumService bProjSumService; 
	
	/**
	 * 列表  查询所有
	 * 
	 * @param searchTxt
	 * @param page
	 * @param model
	 * @return
	 */
	//@AuthPassport(rightCode = "pmp.bprojsum")
	@RequestMapping(value = "/projectHouseList")
	public @ResponseBody
	ResultMessage list(@ModelAttribute SearchVo vo, PageVo pagevo) {
		// 列表查询
		if (pagevo == null) {
			pagevo = new PageVo(0,16);
		}
        Page<BProjSum> page = bProjSumService.getBProjSumList(pagevo, vo.getMap());
        for (BProjSum bproj : page) {
			bproj.setSaleamountsum((double) Math.round(bproj
					.getSaleamountsum() / 10000));
		}
        
		return ResultMessage.successPage(page);
	}
	
	
	/**
	 * 列表  查询在售
	 * 
	 * @param searchTxt
	 * @param page
	 * @param model
	 * @return
	 */
	//@AuthPassport(rightCode = "pmp.bprojsum")
	@RequestMapping(value = "/projectHouseOnList")
	public @ResponseBody
	ResultMessage Onlist(@ModelAttribute SearchVo vo, PageVo pagevo) {
        
		// 列表查询
		if (pagevo == null) {
			pagevo = new PageVo(0,16);
		}
        Page<BProjSum> page = bProjSumService.getBProjSumOnList(pagevo, vo.getMap());
        
        //金额亿转万 四舍五入 保留整数
        for (BProjSum bproj : page) {
			bproj.setSaleamountsum((double) Math.round(bproj
					.getSaleamountsum() / 10000));
		}
        
		return ResultMessage.successPage(page);
	}
	
	
	/**
	 * 列表  查询在售
	 * 
	 * @param searchTxt
	 * @param page
	 * @param model
	 * @return
	 */
	//@AuthPassport(rightCode = "pmp.bprojsum")
	@RequestMapping(value = "/projectHouseEndList")
	public @ResponseBody
	ResultMessage Endlist(@ModelAttribute SearchVo vo, PageVo pagevo) {
        
		// 列表查询
		if (pagevo == null) {
			pagevo = new PageVo(0, 16);
		}
        Page<BProjSum> page = bProjSumService.getBProjSumEndList(pagevo, vo.getMap());
        
        for (BProjSum bproj : page) {
			bproj.setSaleamountsum((double) Math.round(bproj
					.getSaleamountsum() / 10000));
		}
        
		return ResultMessage.successPage(page);
	}
	
	
	/**
	 * 增加  项目汇总信息
	 * 
	 * @return
	 */
	@AuthPassport(rightCode = "pmp.bprojsum")
	@RequestMapping(value = "/bProjSumAdd")
	public @ResponseBody
	ResultMessage add(@Valid @RequestBody BProjSumModel bProjSumModel,
			Errors errors) {
		BProjSum bprojsum = new BProjSum();
		BeanUtils.copyProperties(bProjSumModel, bprojsum);
		bprojsum.setCreate_time((Timestamp) new Date());
		bProjSumService.insert(bprojsum);
		return ResultMessage.successMsg("添加成功");
	}
	
	
	/**
	 * 按区域ID，城市ID来查询
	 * 
	 * @param userId
	 * @return
	 */
	//@AuthPassport(rightCode = "pmp.bprojsum")
	@RequestMapping(value = "/bProjSumSearch")
	public @ResponseBody
	ResultMessage detail(@RequestParam Integer area_id,Integer cityCode) {
		String message = "";
		if (cityCode == null) {
			message = "系统城市ID不能空";
			return ResultMessage.errorMsg(message);
		}
        Map map = new HashMap();
        map.put("area_id", "area_id");
        map.put("cityCode", "cityCode");
		
		BProjSum bprojsum = bProjSumService.getBProjSumById((Integer)map.get("area_id"),(Integer)map.get("cityCode"));
		if (bprojsum == null) {
			message = "未找到该系统区域或者城市";
			return ResultMessage.errorMsg(message);
		}	
		return ResultMessage.successMsg("获取成功", bprojsum);
	}
	
	
	@RequestMapping(value = "/projectHouseQueryList")
	public @ResponseBody
	ResultMessage queryareas() {
		List<BProjSum> listArea = bProjSumService.getAreas();
		List<BProjSum> listCity = bProjSumService.getcityCodes();
		
		List list = new ArrayList();
		for(BProjSum Area : listCity){
			for(BProjSum City : listCity){
				if(Area.getArea_id()==City.getArea_id()){
					list.add(Area.getArea_id()+","+City.getCityCode());
				}
			}
		}
	   
		try {
			String str = gnerateJsonFromObject(list);
			System.out.println(str);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Map map = new HashMap();
		map.put("listArea", listArea);
		map.put("listCity", listCity);
		return ResultMessage.successMsg("获取成功", map);
	}
	
	
	public static String gnerateJsonFromObject(Object object) throws Exception {  
        ObjectMapper mapper = new ObjectMapper();  
        return mapper.writeValueAsString(object);  
    }
	
	
}
