package com.sxit.mgt.pmp.dto;

public class RptProjCstIndustryModel{
	

		private Long cst_industry_id;//   	private String proj_id;//   	private String industry_id;//   	private Integer cst_num;//   	private java.sql.Timestamp create_time;//   	public Long getCst_industry_id() {	    return this.cst_industry_id;	}	public void setCst_industry_id(Long cst_industry_id) {	    this.cst_industry_id=cst_industry_id;	}	public String getProj_id() {	    return this.proj_id;	}	public void setProj_id(String proj_id) {	    this.proj_id=proj_id;	}	public String getIndustry_id() {	    return this.industry_id;	}	public void setIndustry_id(String industry_id) {	    this.industry_id=industry_id;	}	public Integer getCst_num() {	    return this.cst_num;	}	public void setCst_num(Integer cst_num) {	    this.cst_num=cst_num;	}	public java.sql.Timestamp getCreate_time() {	    return this.create_time;	}	public void setCreate_time(java.sql.Timestamp create_time) {	    this.create_time=create_time;	}
	
}
